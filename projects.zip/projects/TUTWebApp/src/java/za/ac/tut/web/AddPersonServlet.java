/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import za.ac.tut.email.Mailer;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.jaxrs.client.NewJerseyClient;

public class AddPersonServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String gender= request.getParameter("gender");
        String streetName= request.getParameter("streetName");
        String houseNumber= request.getParameter("houseNumber");
        String city= request.getParameter("city");
        String areaCode= request.getParameter("areaCode");
        String cellphone= request.getParameter("cellphone");
        String email= request.getParameter("email");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
       
        Mailer.send(email, "Registration", "Successfully Added");
        
        String personXML = generatepersonXML(id, name, surname, gender,streetName,houseNumber,city,areaCode,cellphone,email,username, password);
        NewJerseyClient client = new NewJerseyClient();
        client.create_XML(personXML);
        
        RequestDispatcher disp = request.getRequestDispatcher("/add_person_outcome.jsp");
        disp.forward(request, response);       
    }

    /*private String generatepersonXML(String id, String name, String surname, String houseNumber, String city, String areaCode, String cellphone, String email, String username, String password) {
        String personXML = "<person>" + 
                                "<id>"       + id           + "</id>"      +
                                "<name>"     + name         + "</name>"    +
                                "<surname>"  + surname      + "</surname>" +
                                "<surname>"  + surname      + "</surname>" +
                                "<surname>"  + surname      + "</surname>" +
                                "<surname>"  + surname      + "</surname>" +
                                "<surname>"  + surname      + "</surname>" +
                                "<surname>"  + surname      + "</surname>" +
                                "<login>"  + 
                                    "<username>" + username  + "</username>"    +
                                    "<password>" + password  + "</password>"    +
                                "</login>" +
                            "</person>";
        return personXML;
    }*/

    private String generatepersonXML(String id, String name, String surname, String gender, String streetName, String houseNumber, String city, String areaCode, String cellphone, String email, String username, String password) {
     String personXML = "<person>" + 
                                "<id>"       + id           + "</id>"      +
                                "<name>"     + name         + "</name>"    +
                                "<surname>"  + surname      + "</surname>" +
                                "<gender>"  + gender      + "</gender>" +
                                "<streetName>"  + streetName      + "</streetName>" +
                                "<houseNumber>"  + houseNumber      + "</houseNumber>" +
                                "<city>"  + city     + "</city>" +
                                "<areaCode>"  + areaCode      + "</areaCode>" +
                                "<cellphone>"  + cellphone      + "</cellphone>" +
                                "<email>"  + email      + "</email>" +
                                "<login>"  + 
                                    "<username>" + username  + "</username>"    +
                                    "<password>" + password  + "</password>"    +
                                "</login>" +
                            "</person>";
        return personXML;
    }

}
