/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.jaxrs.client.NewJerseyClient;

public class UpdatePersonServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String loginName = request.getParameter("subjname");
        String loginCode = request.getParameter("subjcode");
        
        String personXML = generatepersonXML(id, name, surname, loginName, loginCode);
        NewJerseyClient client = new NewJerseyClient();
        client.edit_XML(personXML, id);
        
        RequestDispatcher disp = request.getRequestDispatcher("/update_person_outcome.jsp");
        disp.forward(request, response);       
    }

    private String generatepersonXML(String id, String name, String surname, String loginName, String loginCode) {
        String personXML = "<person>" + 
                                "<id>"       + id           + "</id>"      +
                                "<name>"     + name         + "</name>"    +
                                "<surname>"  + surname      + "</surname>" +
                                "<login>"  + 
                                    "<name>" + loginName  + "</name>"    +
                                    "<code>" + loginCode  + "</code>"    +
                                "</login>" +
                            "</person>";
        return personXML;
    }

}
