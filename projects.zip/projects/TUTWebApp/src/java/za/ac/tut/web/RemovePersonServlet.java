/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.ClientErrorException;
import za.ac.tut.jaxrs.client.NewJerseyClient;

/**
 *
 * @author MemaniV
 */
public class RemovePersonServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String id = request.getParameter("id");
        
       
        NewJerseyClient client = new NewJerseyClient();
        client.remove(id);
                
        RequestDispatcher disp = request.getRequestDispatcher("/remove_person_outcome.jsp");
        disp.forward(request, response);       
        } catch(ClientErrorException e) {
            throw new ServletException("There's no such a person.");
        }

    }

}
