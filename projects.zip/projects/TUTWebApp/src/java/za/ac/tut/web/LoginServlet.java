
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import za.ac.tut.jaxrs.client.NewJerseyClient;

/**
 *
 * @author v-edkhoz
 */
public class LoginServlet extends HttpServlet {

   @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       try {
           String id = request.getParameter("id");
           String pin = request.getParameter("password");
           //HttpSession session = request.getSession();
           
           NewJerseyClient client = new NewJerseyClient();
           String personJSON = client.find_JSON(String.class, id);
           String url = "";
           
           
           if("".equals(personJSON)) {
               url = "";
           } else {
               String password = "";
           JSONArray persons  = new JSONArray("["+personJSON+"]");
           for(int i = 0; i < persons.length();i++){
               try {
                   JSONObject person = persons.getJSONObject(i);
                  password = person.getJSONObject("login").getString("password");
               } catch (JSONException ex) {
                   Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
               if(password.equalsIgnoreCase(pin)){
               url = "/find_person_outcome.jsp";
               //session.setAttribute("personJSON", personJSON);
               }
           }
           
           //System.out.println(password);
           request.setAttribute("personJSON", personJSON);
           
           RequestDispatcher disp = request.getRequestDispatcher(url);       
           disp.forward(request, response);
       } catch (JSONException ex) {
           Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
       }

    }

}
